# Megabonk — Yedekten Geri Yükleme

Oyuna herhangi bir şey olursa (mod kaynaklı ya da değil) bu adımlarla **tamamen vanilla** hâle dönebilirsin.

## Yedek nerede?

```
D:\Megabonk_Backup_2026-10-26\
├── Game\    → oyun klasörünün birebir kopyası (modlar dahil değil, saf vanilla)
└── Save\    → kayıt dosyaları (progression, unlock'lar, istatistikler)
```

Toplam boyut: ~498 MB. Yedek, modlar kurulmadan **önce** alındı.

## Yöntem 1 — En hızlı: sadece modları kaldır

Modlar oyunu bozmaz, ama "modsuz hâle dönmek" istiyorsan:

1. Oyunu kapat (Steam'de tamamen çıkış).
2. Şu klasörü sil veya adını değiştir:
   `D:\SteamLibrary\steamapps\common\Megabonk\BepInEx`
3. Oyunu başlat. Steam "dosya bütünlüğünü doğrula" yapmana gerek yok; oyun BepInEx olmadan da sorunsuz açılır.

Kayıtlar etkilenmez — kayıtlar `BepInEx` klasöründe değil, şurada:

```
C:\Users\<kullanıcı>\AppData\LocalLow\Ved\Megabonk\
```

## Yöntem 2 — Tam geri yükleme (oyun + kayıt)

1. Steam'i kapat.
2. Mevcut oyun klasörünü yedekle (adını `Megabonk_eski` yap) — geri dönmek istersen lazım olur:
   `D:\SteamLibrary\steamapps\common\Megabonk`
3. Yedekteki `Game` klasörünün **içeriğini** oyun klasörüne kopyala:
   ```powershell
   robocopy "D:\Megabonk_Backup_2026-10-26\Game" "D:\SteamLibrary\steamapps\common\Megabonk" /E /COPYALL
   ```
4. Kayıtları geri yükle:
   ```powershell
   robocopy "D:\Megabonk_Backup_2026-10-26\Save" "$env:USERPROFILE\AppData\LocalLow\Ved\Megabonk" /E /COPYALL
   ```
5. Steam'i aç, oyunu başlat.

## Sadece kaydı geri almak

Modlar hiçbir zaman kayıt dosyalarını değiştirmez (BonkMentor tamamen görsel, hiçbir satın alma/seçim yapmaz). Yine de bir sorun olursa:

```powershell
robocopy "D:\Megabonk_Backup_2026-10-26\Save" "$env:USERPROFILE\AppData\LocalLow\Ved\Megabonk" /E /COPYALL
```

## Sadece BonkMentor'u kapatmak (oyunu silmeden)

1. `D:\SteamLibrary\steamapps\common\Megabonk\BepInEx\plugins\BonkMentor.dll` dosyasını sil.
2. Oyunu yeniden başlat.

BetterMinimap çalışmaya devam eder, oyun normal açılır.

## BonkMentor'u tamamen kapatmak (ama kurulu kalsın)

`D:\SteamLibrary\steamapps\common\Megabonk\BepInEx\config\com.mehme.bonkmentor.cfg` dosyasını aç ve:

```ini
[General]
Enabled = false
```

Oyunu yeniden başlat. Mod yüklenir ama hiçbir rozet/tooltip çizmez.

## Not

- Mod yalnızca arayüz çizer. Hasar, drop oranı, ekonomi, kayıt — hiçbirine dokunmaz.
- Score hesabı deterministik: aynı karakter + aynı silahlarla hep aynı sonucu verir.
- Sorun olursa `D:\SteamLibrary\steamapps\common\Megabonk\BepInEx\LogOutput.log` dosyasına bak; `BonkMentor` satırları ne olduğunu söyler.
