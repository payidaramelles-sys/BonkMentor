# BonkMentor

Megabonk için **seçim danışmanı**: yükseltme tekliflerini mevcut karakterine ve silahlarına göre puanlar. Hiçbir şeyi otomatik seçmez, oyunu ve kaydını değiştirmez. Sadece gösterir.

## Ne yapar?

- **Yükseltme ekranı**: her teklifin köşesinde rozetler çıkar — sahip olduğun her silah için bir işaret, artı bir karakter işareti.
  - `++` / `+` iyi, `~` nötr, `x` zararlı veya işe yaramaz, `?` bilinmiyor.
- **İpucu (tooltip)**: karta gelince ayrıntılı döküm — hangi silah ne kadar kazanıyor, karakter ne düşünüyor, toplam puan ve yorum (`Güçlü`, `Nötr`, `Zayıf`…).
- **En iyi kart vurgusu**: en yüksek puanlı kartın çevresi ince yeşil bir çizgiyle işaretlenir.
- **Sandık ekranı** ve **karşılaşma teklifleri** aynı rozet ve vurguyla değerlendirilir:
  - **Charge Shrine (kule)** ve diğer tapınaklar,
  - **Moai** (Madagaskar heykeli, “Öğeler senin için” ekranı),
  - **Şüpheli Adam** (para ile eşya satan şapkalı adam — `SetItemPriced` kartları).
- **Envanter ipuçları**: sahip olduğun eşya ve silahların ipucuna puan satırı eklenir.
- **Karakter seçimi**: karakter açıklamasının altına `BonkMentor: Saldırı + · Savunma ~ · Hareket + · Fayda + · Başlangıç: Kemik` satırı düşer.

## Puanlama nasıl çalışıyor?

Toplam puan üç parçanın ağırlıklı ortalamasıdır:

| Parça | Ağırlık |
| --- | --- |
| Silah ortalaması (her silahın o tekliften kazancı) | %55 |
| Karakter uyumu | %25 |
| Genel fayda | %20 |

Değerler oyunun kendi verisinden okunur: silah taban istatistikleri, karakterin kategori eğilimleri, yükseltme tekliflerinin istatistik değiştiricileri. Bilinmeyen veri `?` olarak gösterilir, uydurulmaz.

### Eşyalar ve kart metni

Oyunda eşyaların (item) istatistik verisi tutulmuyor: 87 eşyanın hiçbirinde `statModifiers` alanı dolu değil — etkileri kodun içinde tanımlı. Bu yüzden eşya kartlarında puan, **kartta yazan metinden** okunan sayılarla hesaplanır (`+15% hasar`, `+2 maksimum can`, `+20% hareket hızı` gibi). Bu durumda ipucunun sonunda `(kart metninden okundu)` notu çıkar.

Metinden de sayı okunamıyorsa işaret `?` kalır — mod hiçbir zaman tahmini bir sayı uydurmaz.

## Kurulum

1. BepInEx 6 (IL2CPP) kurulu olmalı — paket bağımlılığı olarak listede.
2. `BonkMentor.dll` dosyasını `BepInEx/plugins/` klasörüne at.
3. Oyunu başlat. Log'da `BonkMentor 1.0.0 loaded` satırını görmelisin.

## Ayarlar

`BepInEx/config/com.mehme.bonkmentor.cfg` dosyasından veya oyun içi Configuration Manager'dan:

- `Genel > Etkin` — modu tamamen aç/kapat.
- `Genel > Dil` — `tr` (varsayılan) veya `en`.
- `Arayüz > İpuçları` — ayrıntılı ipucunu göster/gizle.
- `Arayüz > En İyi Vurgusu` — en iyi kart çerçevesini aç/kapat.
- `Arayüz > Vurgu Rengi` — varsayılan `#19FF59`.
- `Arayüz > Rozet Ölçeği` — 0.6 – 1.8.
- `Arayüz > Rozet Köşesi` — `BottomRight` (varsayılan), `TopRight`, `TopLeft`, `BottomLeft`.
- `Arayüz > Rozet Arka Planı` — rozetlerin arkasındaki koyu şerit.

## Uyumluluk

- Megabonk 1.0.69 (Unity 2023.2.22f1) üzerinde geliştirildi.
- **MegabonkBetterMinimap** ve **StatHUD** ile birlikte test edildi, çakışma yok.
- Oyun güncellemesinden sonra sınıf/gövde isimleri değişirse rozetler susabilir; mod yine de oyunu bozmaz (tüm kancalar korumalı).

## Notlar

- Mod tamamen istemci taraflı ve görseldir; çok oyunculuda diğer oyunculara etkisi yoktur.
- Puanlar deterministiktir: aynı teklif, aynı karakter, aynı silahlar → aynı puan.
